﻿using NetFwTypeLib;
using System;

namespace Traversal
{
    public static class Firewall
    {
        private static readonly INetFwPolicy2 FwPolicy2;

        static Firewall()
        {
            FwPolicy2 = (INetFwPolicy2) Activator.CreateInstance(Type.GetTypeFromProgID("HNetCfg.FwPolicy2"));
        }

        public static void AddRule(string name, string applicationName, int protocol, bool edgeTraversal)
        {
            var rule = (INetFwRule2) Activator.CreateInstance(Type.GetTypeFromProgID("HNetCfg.FWRule"));
            rule.Enabled = true;
            rule.Action = NET_FW_ACTION_.NET_FW_ACTION_ALLOW;

            rule.Name = name;
            rule.ApplicationName = applicationName;
            rule.Protocol = protocol;
            rule.EdgeTraversal = edgeTraversal;

            FwPolicy2.Rules.Add(rule);
        }

        public static INetFwRule GetRule(string name)
        {
            try
            {
                var rule = FwPolicy2.Rules.Item(name);
                return rule;
            }
            catch
            {
                return null;
            }
        }

        public static void DeleteRule(INetFwRule rule)
        {
            FwPolicy2.Rules.Remove(rule.Name);
        }
    }
}