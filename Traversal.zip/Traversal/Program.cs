﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Security.Principal;
using System.Text;

namespace Traversal
{
    internal class Program
    {
        private static List<IPEndPoint> _peers;
        private static UdpClient _client;

        private static void Main(string[] args)
        {
            if (!IsAdministrator())
            {
                Console.WriteLine("Administrator");
                Console.ReadLine();
                return;
            }

            _peers = new List<IPEndPoint>();

            if (args.Length == 2)
            {
                IPAddress address;
                if (IPAddress.TryParse(args[0], out address))
                {
                    int port;
                    if (int.TryParse(args[1], out port))
                    {
                        try
                        {
                            var remoteEp = new IPEndPoint(address, port);
                            _peers.Add(remoteEp);
                        }
                        catch
                        {
                            // ignored
                        }
                    }
                }
            }

            FirewallHandling();

            _client = new UdpClient(0, AddressFamily.InterNetworkV6);
            _client.AllowNatTraversal(true);

            var localAddress = GetIPv6Teredo();
            var localPort = ((IPEndPoint) _client.Client.LocalEndPoint).Port;

            Console.WriteLine("{0} {1}", localAddress, localPort);

            _client.BeginReceive(ReceiveCallback, null);

            while (true)
            {
                var data = Console.ReadLine();
                if (data == null)
                    continue;

                data = data.Trim();

                if (data.Length == 0)
                    continue;

                var buffer = Encoding.UTF8.GetBytes(data);
                _peers.ForEach((peer) => _client.BeginSend(buffer, buffer.Length, peer, SendCallback, null));
            }
        }

        private static void ReceiveCallback(IAsyncResult ar)
        {
            var remoteEp = new IPEndPoint(IPAddress.IPv6Any, 0);
            var buffer = _client.EndReceive(ar, ref remoteEp);

            var data = Encoding.UTF8.GetString(buffer);
            Console.WriteLine("[{0}:{1}] {2}", remoteEp.Address, remoteEp.Port, data);

            if (!_peers.Exists((peer) => peer.Address.Equals(remoteEp.Address) && peer.Port == remoteEp.Port))
                _peers.Add(remoteEp);

            _client.BeginReceive(ReceiveCallback, null);
        }

        private static void SendCallback(IAsyncResult ar)
        {
            _client.EndSend(ar);
        }

        public static bool IsAdministrator()
        {
            return (new WindowsPrincipal(WindowsIdentity.GetCurrent())).IsInRole(WindowsBuiltInRole.Administrator);
        }

        private static void FirewallHandling()
        {
            var appName = Process.GetCurrentProcess().MainModule.FileName.ToLower();
            var rule = Firewall.GetRule("Traversal");

            if (rule == null)
            {
                Firewall.AddRule("Traversal", appName, 17, true);
            }
            else
            {
                if (rule.ApplicationName.ToLower() == appName)
                    return;

                Firewall.DeleteRule(rule);
                Firewall.AddRule("Traversal", appName, 17, true);
            }
        }

        private static IPAddress GetIPv6Teredo()
        {
            return
                IPGlobalProperties.GetIPGlobalProperties().GetUnicastAddresses()
                    .FirstOrDefault(a => a.Address.IsIPv6Teredo)?.Address;
        }
    }
}